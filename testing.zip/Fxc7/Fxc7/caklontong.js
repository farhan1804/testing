[
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Menjadi komandan upacara 17-an, komandan upacara harus siap",
        "jawaban": "Serak",
        "desc": "Jawaban: Serak (Harus siap serak, kan teriak-teriak)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Galang menyimpan buku di\u2026",
        "jawaban": "Mas",
        "desc": "Jawaban: Mas (Bukunya mas dipinjam galang kemarin sore)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Mahasiswa yang ingin meraih gelar sarjana harus menyelesaikan...",
        "jawaban": "Sendiri",
        "desc": "Jawaban: Sendiri (Masa kamu pas lagi sidang diwakilin, ngga bisa dong, harus diselesaikan sendiri)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Yang menarik gerbong kereta api",
        "jawaban": "Lokuatgak",
        "desc": "Jawaban: Lokuatgak",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Sisi x sisi untuk menghitung luas...",
        "jawaban": "Kosan",
        "desc": "Jawaban: Kosan (Selain untuk menghitung luas kotak, sisi x sisi juga bisa untuk menghitung luas kosan)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Tempat barang yang jarang dipakai dan banyak debunya",
        "jawaban": "Rumah",
        "desc": "Jawaban: Rumah (Rumah kosong itu udah pasti jarang dipakai dan banyak debunya)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Yang menyebabkan orang haus saat ramadhan",
        "jawaban": "Cuaca",
        "desc": "Jawaban: Cuaca (Wah apalagi kalau cuacanya terik banget, bikin haus)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Mamat dimarahi ibu guru, karena kemarin ... sekolah",
        "jawaban": "Bobol",
        "desc": "\nJawaban: Bobol (Kalau bobol sekolah, itu perbuatan yang keterlaluan makanya dimarahi ibu guru)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Apabila mengendarai mobil wajib bawa",
        "jawaban": "Satu",
        "desc": "Jawaban: Satu (Kalo bawa 2 gimana mengendarainya)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Memasak tempe terlalu lama",
        "jawaban": "Garing",
        "desc": "Jawaban: Garing (Kalau gosong belum tentu, tapi kalau garing udah pasti)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Tempat barang yang jarang dipakai dan banyak debunya",
        "jawaban": "Rumah",
        "desc": "Jawaban: Rumah (Rumah kosong itu udah pasti jarang dipakai dan banyak debunya)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Orang batuk, dilarang minum...",
        "jawaban": "Bensin",
        "desc": "Jawaban: Bensin (Wah sangat tidak disarankan kalau lagi batuk minum bensin, bukan batuk aja yang makin parah tapi nyawa juga terancam, makanya dilarang)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Kita bisa dengar suara motor lewat...",
        "jawaban": "Kampung",
        "desc": "Jawaban: Kampung (Kalau ada motor lewat kita bisa dengar kan? Itu motor lagi lewat kampung rumah kita)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Gajah bisa menyemprotkan air karena punya...",
        "jawaban": "Kemauan",
        "desc": "Jawaban: Kemauan (Gajah nyemprotin air itu atas kemaunnya sendiri, ngga nyemprot gitu aja, misalnya nyemprotin air pas lagi mau mandi)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Halaman menjadi lebih indah kalau dikasih...",
        "jawaban": "Rumah",
        "desc": "Jawaban: Rumah (Ya percuma dong kalau halaman ngga ada rumahnya, itu disebutnya lahan kosong bukan halaman)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Harimau mati meninggal kan",
        "jawaban": "Setuju",
        "desc": "Jawaban: Setuju (Harimau mati meninggal kan? Setuju! Harimau yang mati pasti meninggal)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Sebelum jadi katak, anak katak disebut",
        "jawaban": "Remaja",
        "desc": "Jawaban: Remaja (Nah proses sebelum menjadi dewasa yaitu menjadi katak, anak katak harus melalui masa-masa remaja dulu kan)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Tidak punya uang sepeserpun",
        "jawaban": "Kera",
        "desc": "Jawaban: Kera (Kera memang punya uang? Mau disimpan dimana coba)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Kambing yang ditusuk-tusuk dan siap dibakar, jadi...",
        "jawaban": "Lari",
        "desc": "Jawaban: Lari (Hewan itu pasti lari dong, dia kan ngga mau kalau dijadiin sate)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Selain motor, truk, bus, di jalan raya juga ada...",
        "jawaban": "IIIII",
        "desc": "Jawaban: IIIII (Kalau kamu jeli, kamu pasti lihat kalau di jalan raya itu ada marka jalan yang garisnya putus-putus)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Minuman yang kita masukkan ke kulkas, pasti...",
        "jawaban": "Ringan",
        "desc": "Jawaban: Ringan (Yang kita masukkan ke dalam kulkas pasti minuman yang ringan, memangnya seberat apa minuman yang dimasukkan ke dalam kulkas?)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Supaya tampil maksimal, seorang penyanyi harus cek...",
        "jawaban": "Saldo",
        "desc": "\nJawaban: Saldo (Sebelum tampil biasanya penyanyi cek saldo dulu, apakah dp atau bayarannya sudah masuk atau belum, supaya tampil maksimal dong)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Orang yang tidur, kedua matanya harus...",
        "jawaban": "Dekat",
        "desc": "Jawaban: Dekat (Kalau berjauhan kedua matanya mana bisa tidur, yang ada matanya malah kebuka terus, jadi mata bagian atas dan bawah harus dekat supaya bisa nutup)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Lawannya gemuk",
        "jawaban": "Takut",
        "desc": "\nJawaban: Takut (Ih, takut kalau lawannya gemuk)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Matahari, bulan, bintang, awan, pesawat, burung..., Itu semuanya ada di...",
        "jawaban": "Bacain",
        "desc": "Jawaban: Bacain (Tadi semuanya itu udah dibacain ke kamu kan)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Supaya lebih cepat sampai di tujuan, orang biasanya memilih alternatif lewat jalan...",
        "jawaban": "Terus",
        "desc": "Jawaban: Terus (Karena kalau ngga jalan terus ngga ketemu-ketemu jalan alternatif yang dicari)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Untuk menyalakan lampu, kita harus pencet...",
        "jawaban": "Sekali",
        "desc": "Jawaban: Sekali (Kalau dari posisi mati terus kita pencet dua kali saklarnya ya pasti mati lagi lampunya)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Bersatu kita teguh bercerai kita",
        "jawaban": "Sedih",
        "desc": "Jawaban: Sedih (Siapa yang gak sedih cerai sama istri??)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Matahari, bulan, bintang, awan, pesawat, burung..., Itu semuanya ada di...",
        "jawaban": "Bacain",
        "desc": "Jawaban: Bacain (Tadi semuanya itu udah dibacain ke kamu kan)",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Rasanya pedas",
        "jawaban": "Sshahh",
        "desc": "Jawaban: Sshahh (Kalau kamu makan makanan pedas rasanya gimana? Pasti keluar bunyi \"sshahh\")",
        "poin": 5
    }
}
]