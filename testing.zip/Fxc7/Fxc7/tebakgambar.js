[
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/ycjnxwzo",
        "jawaban": "Kacang hijau",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y9f9482e",
        "jawaban": "Tebak Gambar",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/yajqrffd",
        "jawaban": "Kecantikan wajah",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/yauru4h7",
        "jawaban": "Kuli panggul",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y8jdayjn",
        "jawaban": "Sangat meragukan",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/ycnjssa5",
        "jawaban": "Pecahan kaca",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/ybyrgvkj",
        "jawaban": "Keong racun",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/yabxcnt8",
        "jawaban": "Kain pembungkus",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y9mokelf",
        "jawaban": "Piring terbang",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y9a7sfgb",
        "jawaban": "Penyusutan aset",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/ycv7zxj9",
        "jawaban": "Cakar kucing",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y7c59fgx",
        "jawaban": "Kenyataan pahit",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y9j2vavn",
        "jawaban": "Kolam mujair",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y8mz6vfp",
        "jawaban": "Angkat kaki",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/yaffczbc",
        "jawaban": "Ikrar janji",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y7zqpnce",
        "jawaban": "Seratus milyar",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y7us5qez",
        "jawaban": "Sepiring papeda",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/ybx758q7",
        "jawaban": "Keluaran terbagus",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y86jq94l",
        "jawaban": "Tambah besar",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/ybtnfjr4",
        "jawaban": "Perkataanku jujur",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y77foxpz",
        "jawaban": "Kerabat jauh",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/ybu4e5aj",
        "jawaban": "Sekarang saja",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/ycoklqtp",
        "jawaban": "Kelakar tawa",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y8bt3436",
        "jawaban": "Laba bisnis",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/ybtnfjr4",
        "jawaban": "Perkataanku jujur",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/ya2ec47f",
        "jawaban": "Harga daging kambing jantan melonjak naik",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/yasxc5w6",
        "jawaban": "Pasang spanduk",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y73ku7wq",
        "jawaban": "Jualan kipas",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y8t7lolf",
        "jawaban": "Kurang serius",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y7cprx7f",
        "jawaban": "Tambal gigi",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/yb6qq9pm",
        "jawaban": "Penguasa wilayah",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/yd7ccclg",
        "jawaban": "Jalur difabel",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y9mokelf",
        "jawaban": "Piring terbang",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/ycx6ggud",
        "jawaban": "Jujur adil",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/ybd976b4",
        "jawaban": "Kolam susu",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y9436p59",
        "jawaban": "Minum susu setiap malam agar sehat",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y9mokelf",
        "jawaban": "Piring terbang",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/ydxoozrm",
        "jawaban": "Gurita raksasa",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/ydh93b8w",
        "jawaban": "Buka dokumen",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y855dd98",
        "jawaban": "Sampah plastik akan merusak ekosistem laut",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/ycmtrkey",
        "jawaban": "Saudagar kopi berusaha merayu raja",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y92ybjns",
        "jawaban": "Ketemu mantan",
        "poin": 5
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soalImg": "https://tinyurl.com/y9mokelf",
        "jawaban": "Piring terbang",
        "poin": 5
    }
}
]