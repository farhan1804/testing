exports.limitend = (pushname2) => {
	return`*maaf ${pushname2} limit hari ini habis*`
}
exports.afkOn = (pushname2, reason) => {
    return `Fitur AFK berhasil *diaktifkan*!\n\n➸ *Username*: ${pushname2}\n➸ *Alasan*: ${reason}`
}

exports.afkOnAlready = () => {
    return `Fitur AFK telah diaktifkan sebelumnya.`
}

exports.afkMentioned = (getReason, getTime) => {
    return `*「 AFK MODE 」*\n\nSssttt! Orangnya lagi AFK, jangan diganggu!\n➸ *Alasan*: ${getReason}\n➸ *Sejak*: ${getTime}`
}

exports.afkDone = (pushname2) => {
    return `*${pushname2}* telah kembali dari AFK! Selamat datang kembali~`
}
